import React, { useState } from "react";

export default function IngestPanel({ onIngest, ingesting, error }) {
  const [yt, setYt] = useState("");
  const [ig, setIg] = useState("");

  return (
    <div className="ingest-panel">
      <h2>Enter Video URLs</h2>
      <div className="ingest-form">
        <label>
          🎥 YouTube URL (Video A)
          <input
            type="url"
            placeholder="https://youtube.com/watch?v=..."
            value={yt}
            onChange={e => setYt(e.target.value)}
          />
        </label>
        <label>
          📱 Instagram Reel URL (Video B)
          <input
            type="url"
            placeholder="https://instagram.com/reel/..."
            value={ig}
            onChange={e => setIg(e.target.value)}
          />
        </label>
        {error && <p className="error">{error}</p>}
        <button
          className="ingest-btn"
          onClick={() => onIngest(yt, ig)}
          disabled={ingesting || !yt || !ig}
        >
          {ingesting ? "⏳ Fetching & Embedding..." : "🚀 Analyse Videos"}
        </button>
      </div>
      <div className="suggested-questions">
        <p>After ingestion, ask things like:</p>
        <ul>
          <li>"Why did Video A get more engagement than Video B?"</li>
          <li>"What's the engagement rate of each?"</li>
          <li>"Compare the hooks in the first 5 seconds."</li>
          <li>"Suggest improvements for B based on what worked in A."</li>
        </ul>
      </div>
    </div>
  );
}
