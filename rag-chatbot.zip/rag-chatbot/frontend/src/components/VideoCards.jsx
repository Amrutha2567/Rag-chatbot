import React from "react";

function StatBadge({ label, value }) {
  return (
    <div className="stat-badge">
      <span className="stat-label">{label}</span>
      <span className="stat-value">{value ?? "N/A"}</span>
    </div>
  );
}

function VideoCard({ video, label, color }) {
  if (!video) return null;
  return (
    <div className="video-card" style={{ borderTop: `4px solid ${color}` }}>
      <div className="video-card-header">
        <span className="video-label" style={{ background: color }}>Video {label}</span>
        <span className="platform-badge">{video.platform === "youtube" ? "▶ YouTube" : "📱 Instagram"}</span>
      </div>
      <h3 className="video-title">{video.title || "Untitled"}</h3>
      <p className="video-creator">@{video.creator || "Unknown"}</p>
      <div className="stats-grid">
        <StatBadge label="Views" value={video.views?.toLocaleString()} />
        <StatBadge label="Likes" value={video.likes?.toLocaleString()} />
        <StatBadge label="Comments" value={video.comments?.toLocaleString()} />
        <StatBadge label="Followers" value={video.follower_count?.toLocaleString()} />
        <StatBadge label="Duration" value={video.duration ? `${video.duration}s` : null} />
        <StatBadge label="Uploaded" value={video.upload_date} />
      </div>
      <div className="engagement-rate" style={{ background: color + "22", border: `1px solid ${color}` }}>
        <span>Engagement Rate</span>
        <strong>{video.engagement_rate?.toFixed(4)}%</strong>
      </div>
      {video.hashtags?.length > 0 && (
        <div className="hashtags">
          {video.hashtags.slice(0, 6).map((h, i) => (
            <span key={i} className="hashtag">{h}</span>
          ))}
        </div>
      )}
    </div>
  );
}

export default function VideoCards({ videoA, videoB }) {
  return (
    <div className="video-cards">
      <VideoCard video={videoA} label="A" color="#4f8ef7" />
      <VideoCard video={videoB} label="B" color="#f74f8e" />
    </div>
  );
}
