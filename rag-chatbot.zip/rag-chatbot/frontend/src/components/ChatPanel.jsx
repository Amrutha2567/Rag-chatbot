import React, { useState, useRef, useEffect, useCallback } from "react";
import { v4 as uuidv4 } from "uuid";

const SESSION_ID = uuidv4();

const SUGGESTED = [
  "Why did Video A get more engagement than Video B?",
  "What's the engagement rate of each video?",
  "Compare the hooks in the first 5 seconds.",
  "Who's the creator of Video B and what's their follower count?",
  "Suggest improvements for B based on what worked in A.",
];

function SourceChip({ source }) {
  return (
    <span className={`source-chip source-${source.video_id.toLowerCase()}`}>
      Video {source.video_id} · {(source.relevance * 100).toFixed(0)}%
      <span className="source-tooltip">{source.chunk}</span>
    </span>
  );
}

function Message({ msg }) {
  return (
    <div className={`message message-${msg.role}`}>
      <div className="message-bubble">
        <pre className="message-content">{msg.content}</pre>
        {msg.sources?.length > 0 && (
          <div className="sources-row">
            <span className="sources-label">Sources:</span>
            {msg.sources.map((s, i) => <SourceChip key={i} source={s} />)}
          </div>
        )}
      </div>
    </div>
  );
}

export default function ChatPanel() {
  const [messages, setMessages] = useState([
    { role: "assistant", content: "👋 Videos analysed! Ask me anything about Video A vs Video B.", sources: [] }
  ]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const bottomRef = useRef(null);
  const abortRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = useCallback(async (text) => {
    const userMsg = text.trim();
    if (!userMsg || streaming) return;

    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMsg, sources: [] }]);
    setStreaming(true);

    // Build history for memory (exclude the initial assistant greeting)
    const history = messages
      .filter(m => m.role !== "assistant" || m.sources !== undefined)
      .slice(-10)
      .map(m => ({ role: m.role, content: m.content }));

    // Add streaming placeholder
    setMessages(prev => [...prev, { role: "assistant", content: "", sources: [], streaming: true }]);

    try {
      abortRef.current = new AbortController();
      const res = await fetch("/api/chat/stream", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg, session_id: SESSION_ID, history }),
        signal: abortRef.current.signal,
      });

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let finalSources = [];

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop();

        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const payload = JSON.parse(line.slice(6));

          if (payload.type === "token") {
            setMessages(prev => {
              const updated = [...prev];
              const last = { ...updated[updated.length - 1] };
              last.content += payload.content;
              updated[updated.length - 1] = last;
              return updated;
            });
          } else if (payload.type === "sources") {
            finalSources = payload.sources;
          } else if (payload.type === "done") {
            setMessages(prev => {
              const updated = [...prev];
              const last = { ...updated[updated.length - 1], streaming: false, sources: finalSources };
              updated[updated.length - 1] = last;
              return updated;
            });
          }
        }
      }
    } catch (e) {
      if (e.name !== "AbortError") {
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1] = { role: "assistant", content: "Error: " + e.message, sources: [] };
          return updated;
        });
      }
    } finally {
      setStreaming(false);
    }
  }, [messages, streaming]);

  return (
    <div className="chat-panel">
      <div className="chat-header">💬 Ask the Analyst</div>
      <div className="chat-messages">
        {messages.map((msg, i) => <Message key={i} msg={msg} />)}
        <div ref={bottomRef} />
      </div>
      <div className="suggested-chips">
        {SUGGESTED.map((q, i) => (
          <button key={i} className="chip" onClick={() => sendMessage(q)} disabled={streaming}>
            {q}
          </button>
        ))}
      </div>
      <div className="chat-input-row">
        <textarea
          className="chat-input"
          placeholder="Ask about engagement, hooks, creator info, improvements..."
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(input); } }}
          disabled={streaming}
          rows={2}
        />
        <button
          className="send-btn"
          onClick={() => sendMessage(input)}
          disabled={streaming || !input.trim()}
        >
          {streaming ? "⏳" : "➤"}
        </button>
      </div>
    </div>
  );
}
