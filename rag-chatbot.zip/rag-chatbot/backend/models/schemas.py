from pydantic import BaseModel
from typing import Optional, List

class VideoIngestRequest(BaseModel):
    youtube_url: str
    instagram_url: str

class VideoMetadata(BaseModel):
    video_id: str          # "A" or "B"
    url: str
    platform: str          # "youtube" | "instagram"
    title: Optional[str]
    creator: Optional[str]
    follower_count: Optional[int]
    views: Optional[int]
    likes: Optional[int]
    comments: Optional[int]
    hashtags: List[str]
    upload_date: Optional[str]
    duration: Optional[int]  # seconds
    engagement_rate: Optional[float]

class IngestResponse(BaseModel):
    success: bool
    video_a: VideoMetadata
    video_b: VideoMetadata
    message: str

class ChatMessage(BaseModel):
    role: str   # "user" | "assistant"
    content: str

class ChatRequest(BaseModel):
    message: str
    session_id: str
    history: List[ChatMessage] = []

class ChatSource(BaseModel):
    video_id: str
    chunk: str
    relevance: float

class ChatResponse(BaseModel):
    answer: str
    sources: List[ChatSource]
    session_id: str
