from fastapi import APIRouter, HTTPException
from models.schemas import VideoIngestRequest, IngestResponse
from services.youtube_service import fetch_youtube_data
from services.instagram_service import fetch_instagram_data
from services.vector_store import ingest_transcript

router = APIRouter()

# In-memory store for current session video metadata
_video_store: dict = {}


@router.post("", response_model=IngestResponse)
async def ingest_videos(req: VideoIngestRequest):
    try:
        meta_a, transcript_a = fetch_youtube_data(req.youtube_url, "A")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"YouTube fetch failed: {str(e)}")

    try:
        meta_b, transcript_b = fetch_instagram_data(req.instagram_url, "B")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Instagram fetch failed: {str(e)}")

    # Embed and store both
    chunks_a = ingest_transcript(meta_a, transcript_a)
    chunks_b = ingest_transcript(meta_b, transcript_b)

    # Cache metadata for /api/videos endpoint
    _video_store["A"] = meta_a
    _video_store["B"] = meta_b

    return IngestResponse(
        success=True,
        video_a=meta_a,
        video_b=meta_b,
        message=f"Ingested Video A ({chunks_a} chunks) and Video B ({chunks_b} chunks) successfully.",
    )


def get_video_store():
    return _video_store
