from fastapi import APIRouter, HTTPException
from routers.ingest import get_video_store

router = APIRouter()


@router.get("")
def get_videos():
    store = get_video_store()
    if not store:
        raise HTTPException(status_code=404, detail="No videos ingested yet.")
    return {
        "video_a": store.get("A"),
        "video_b": store.get("B"),
    }
