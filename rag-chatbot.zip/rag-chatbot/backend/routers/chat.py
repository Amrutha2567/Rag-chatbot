import json
import uuid
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from models.schemas import ChatRequest
from services.rag_service import stream_rag_response

router = APIRouter()


@router.post("/stream")
async def chat_stream(req: ChatRequest):
    session_id = req.session_id or str(uuid.uuid4())

    async def event_generator():
        sources_sent = False
        async for token, sources in stream_rag_response(req.message, req.history):
            if token:
                yield f"data: {json.dumps({'type': 'token', 'content': token, 'session_id': session_id})}\n\n"
            elif sources and not sources_sent:
                sources_payload = [s.model_dump() for s in sources]
                yield f"data: {json.dumps({'type': 'sources', 'sources': sources_payload, 'session_id': session_id})}\n\n"
                sources_sent = True
        yield f"data: {json.dumps({'type': 'done', 'session_id': session_id})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
