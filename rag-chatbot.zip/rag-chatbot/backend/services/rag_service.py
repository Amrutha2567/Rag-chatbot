import os
from typing import AsyncGenerator, List
from langchain_anthropic import ChatAnthropic
from langchain.schema import HumanMessage, AIMessage, SystemMessage
from services.vector_store import similarity_search
from models.schemas import ChatMessage, ChatSource

SYSTEM_PROMPT = """You are a video content analyst assistant. You have access to transcripts and metadata 
from two social media videos: Video A (YouTube) and Video B (Instagram Reel).

Your job is to help content creators understand engagement, compare videos, and suggest improvements.

When answering:
- Always cite which video (A or B) and which part of the content you're referencing.
- Be specific with numbers (engagement rates, views, likes, etc.) when available.
- If comparing hooks, reference the first chunk of each transcript.
- Be concise but insightful.
- Format engagement rates to 4 decimal places.

Available context will be injected per query via RAG retrieval.
"""

def _build_context(docs_with_scores) -> tuple[str, List[ChatSource]]:
    context_parts = []
    sources = []
    for doc, score in docs_with_scores:
        vid = doc.metadata.get("video_id", "?")
        chunk_idx = doc.metadata.get("chunk_index", 0)
        context_parts.append(f"[Video {vid}, Chunk {chunk_idx}]\n{doc.page_content}")
        sources.append(ChatSource(
            video_id=vid,
            chunk=doc.page_content[:200] + ("..." if len(doc.page_content) > 200 else ""),
            relevance=round(score, 4),
        ))
    return "\n\n---\n\n".join(context_parts), sources


def _build_messages(
    history: List[ChatMessage],
    user_message: str,
    context: str,
) -> list:
    messages = [SystemMessage(content=SYSTEM_PROMPT)]

    for msg in history[-6:]:  # Keep last 6 turns for memory
        if msg.role == "user":
            messages.append(HumanMessage(content=msg.content))
        else:
            messages.append(AIMessage(content=msg.content))

    augmented_query = (
        f"Relevant context from video transcripts and metadata:\n\n"
        f"{context}\n\n"
        f"---\n\nUser question: {user_message}"
    )
    messages.append(HumanMessage(content=augmented_query))
    return messages


async def stream_rag_response(
    user_message: str,
    history: List[ChatMessage],
) -> AsyncGenerator[tuple[str, List[ChatSource]], None]:
    """Streams answer tokens and yields sources at the end."""

    # 1. Retrieve relevant chunks
    docs_with_scores = similarity_search(user_message, k=6)
    context, sources = _build_context(docs_with_scores)

    # 2. Build message chain
    messages = _build_messages(history, user_message, context)

    # 3. Stream from Claude
    llm = ChatAnthropic(
        model="claude-3-5-sonnet-20241022",
        anthropic_api_key=os.getenv("ANTHROPIC_API_KEY"),
        max_tokens=1024,
        streaming=True,
    )

    full_answer = ""
    async for chunk in llm.astream(messages):
        token = chunk.content
        if token:
            full_answer += token
            yield token, []

    # Yield sources as final signal
    yield "", sources
