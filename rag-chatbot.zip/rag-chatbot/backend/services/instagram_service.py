import re
import yt_dlp
from models.schemas import VideoMetadata


def fetch_instagram_data(url: str, video_id_label: str) -> tuple[VideoMetadata, str]:
    """Returns (VideoMetadata, transcript_text)
    
    Note: Instagram severely limits public API access.
    yt-dlp fetches public reel metadata without auth.
    Transcript is derived from caption/description since Instagram
    does not provide auto-captions via public means.
    For private content, set INSTAGRAM_SESSION_ID in .env
    """
    ydl_opts = {
        "quiet": True,
        "skip_download": True,
        "extract_flat": False,
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)

    views = info.get("view_count") or 0
    likes = info.get("like_count") or 0
    comments = info.get("comment_count") or 0
    engagement = round((likes + comments) / views * 100, 4) if views > 0 else 0.0

    # Extract hashtags from description
    description = info.get("description") or ""
    hashtags = re.findall(r"#\w+", description)

    metadata = VideoMetadata(
        video_id=video_id_label,
        url=url,
        platform="instagram",
        title=info.get("title") or info.get("description", "")[:80],
        creator=info.get("uploader") or info.get("channel"),
        follower_count=info.get("channel_follower_count"),
        views=views,
        likes=likes,
        comments=comments,
        hashtags=hashtags,
        upload_date=info.get("upload_date"),
        duration=info.get("duration"),
        engagement_rate=engagement,
    )

    # Use caption as transcript — Instagram has no auto-captions publicly
    transcript_text = description or f"Instagram reel by {metadata.creator}. Duration: {metadata.duration}s."

    return metadata, transcript_text
