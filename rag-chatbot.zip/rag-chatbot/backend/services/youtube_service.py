import re
import yt_dlp
from youtube_transcript_api import YouTubeTranscriptApi
from models.schemas import VideoMetadata


def extract_youtube_id(url: str) -> str:
    patterns = [
        r"(?:v=|youtu\.be/)([A-Za-z0-9_-]{11})",
        r"(?:shorts/)([A-Za-z0-9_-]{11})",
    ]
    for p in patterns:
        m = re.search(p, url)
        if m:
            return m.group(1)
    raise ValueError(f"Could not extract YouTube video ID from: {url}")


def fetch_youtube_data(url: str, video_id_label: str) -> tuple[VideoMetadata, str]:
    """Returns (VideoMetadata, transcript_text)"""
    vid_id = extract_youtube_id(url)

    ydl_opts = {
        "quiet": True,
        "skip_download": True,
        "extract_flat": False,
    }

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)

    views = info.get("view_count") or 0
    likes = info.get("like_count") or 0
    comments = info.get("comment_count") or 0
    engagement = round((likes + comments) / views * 100, 4) if views > 0 else 0.0

    hashtags = [
        tag for tag in (info.get("tags") or [])
        if tag.startswith("#")
    ] or [f"#{t}" for t in (info.get("tags") or [])[:10]]

    metadata = VideoMetadata(
        video_id=video_id_label,
        url=url,
        platform="youtube",
        title=info.get("title"),
        creator=info.get("uploader"),
        follower_count=info.get("channel_follower_count"),
        views=views,
        likes=likes,
        comments=comments,
        hashtags=hashtags,
        upload_date=info.get("upload_date"),
        duration=info.get("duration"),
        engagement_rate=engagement,
    )

    # Fetch transcript
    try:
        transcript_list = YouTubeTranscriptApi.get_transcript(vid_id)
        transcript_text = " ".join(t["text"] for t in transcript_list)
    except Exception:
        # Fallback: use description + title as pseudo-transcript
        transcript_text = f"{info.get('title', '')}. {info.get('description', '')}"

    return metadata, transcript_text
