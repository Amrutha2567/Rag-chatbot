import os
from typing import List
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.schema import Document
from models.schemas import VideoMetadata

CHROMA_PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", "./chroma_store")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "all-MiniLM-L6-v2")
COLLECTION_NAME = "video_transcripts"

# Singleton embedding model (loaded once, reused)
_embeddings = None

def get_embeddings():
    global _embeddings
    if _embeddings is None:
        _embeddings = HuggingFaceEmbeddings(
            model_name=EMBEDDING_MODEL,
            model_kwargs={"device": "cpu"},
            encode_kwargs={"normalize_embeddings": True},
        )
    return _embeddings


def get_vectorstore() -> Chroma:
    return Chroma(
        collection_name=COLLECTION_NAME,
        embedding_function=get_embeddings(),
        persist_directory=CHROMA_PERSIST_DIR,
    )


def ingest_transcript(metadata: VideoMetadata, transcript: str) -> int:
    """Chunk transcript, tag with video_id, embed and store. Returns chunk count."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=80,
        separators=["\n\n", "\n", ". ", " "],
    )
    chunks = splitter.split_text(transcript)

    # Prepend metadata summary as first chunk for context
    meta_summary = (
        f"[Video {metadata.video_id} Metadata] "
        f"Platform: {metadata.platform}. "
        f"Title: {metadata.title}. "
        f"Creator: {metadata.creator}. "
        f"Followers: {metadata.follower_count}. "
        f"Views: {metadata.views}. Likes: {metadata.likes}. Comments: {metadata.comments}. "
        f"Engagement Rate: {metadata.engagement_rate}%. "
        f"Duration: {metadata.duration}s. Upload Date: {metadata.upload_date}. "
        f"Hashtags: {', '.join(metadata.hashtags)}."
    )
    all_chunks = [meta_summary] + chunks

    docs = [
        Document(
            page_content=chunk,
            metadata={
                "video_id": metadata.video_id,
                "platform": metadata.platform,
                "creator": metadata.creator or "",
                "title": metadata.title or "",
                "engagement_rate": metadata.engagement_rate or 0.0,
                "chunk_index": i,
                "is_metadata": i == 0,
            },
        )
        for i, chunk in enumerate(all_chunks)
    ]

    vs = get_vectorstore()
    # Delete existing chunks for this video_id before re-ingesting
    try:
        vs._collection.delete(where={"video_id": metadata.video_id})
    except Exception:
        pass

    vs.add_documents(docs)
    return len(docs)


def similarity_search(query: str, k: int = 6) -> List[Document]:
    vs = get_vectorstore()
    return vs.similarity_search_with_relevance_scores(query, k=k)
